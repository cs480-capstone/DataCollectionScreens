var colors = ['green','purple'];
var chart = document.getElementById('bargraph').getContext('2d');
var data = [50,50];
var labels;
var title;
var graphtype;

Chart.defaults.global.defaultFontFamily = 'Lato';
Chart.defaults.global.defaultFontSize = 12;
Chart.defaults.global.defaultFontColor = '#777';

function drawGraph(){
    console.log("drawing graph");
    barGraph = new Chart(chart,
        {
            type: 'bar',
            scaleStartValue : 0,
            data:{
                labels:labels,
                datasets:[
                    {
                        label:title,
                        data:data,
                        backgroundColor:colors
                    }
                ]
            },
            options:{
                title:{
                    display: true,
                    text: title,
                    fontSize:20
                },
                legend:{
                    display: false
                },
                tooltips: {
                    enabled: false
               },
               scales: {
                    yAxes: [{
                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                        },
                        ticks: {
                            beginAtZero: true,
                            min:0,
                            stepSize:10,
                            tickThickness: 0
                        }
                    }],
                    xAxes: [{
                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                        }
                    }]
                }
            }
        }
    );
}

document.getElementById("range").onchange = function(){
    barGraph.destroy();
    var value = this.value;
    data = [value,100-value];
    drawGraph();
}

function initGraph(type){
    graphtype = type;
    console.log("made it to init graph with parameter " + graphtype);
    if(graphtype === 'pollen-cones'){
        labels = ['Opened','Not Opened'];
        title = 'Percentage of Open Pollen Cones';
    }
    if(graphtype === 'leaves-unfolding'){
        labels = ['Used','Not Used'];
        title = 'Percentage of Canopy Space Used';
    }
    if(graphtype === 'full-sized-leaves'){
        labels = ['Full','Not Full'];
        title = 'Percentage of Full-Size Leaves';
    }
    if(graphtype === 'colored-leaves'){
        labels = ['Green','Not Green'];
        title = 'Percentage of Colored Leaves';
    }
    if(graphtype === 'open-flowers'){
        labels = ['Open','Not Open'];
        title = 'Percentage of Open Flowers';
    }
    if(graphtype === 'ripe-fruits'){
        labels = ['Ripe','Not Ripe'];
        title = 'Percentage of Ripe Fruit';
    }
    drawGraph();
}

window.onload = function(){
    initGraph("ripe-fruits"); 
}